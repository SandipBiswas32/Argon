package dev.lvstrng.argon.module.modules.combat;

import dev.lvstrng.argon.event.events.AttackListener;
import dev.lvstrng.argon.event.events.TickListener;
import dev.lvstrng.argon.module.Category;
import dev.lvstrng.argon.module.Module;
import dev.lvstrng.argon.module.setting.BooleanSetting;
import dev.lvstrng.argon.module.setting.KeybindSetting;
import dev.lvstrng.argon.module.setting.NumberSetting;
import dev.lvstrng.argon.utils.EncryptedString;
import dev.lvstrng.argon.utils.InventoryUtils;
import dev.lvstrng.argon.utils.MouseSimulation;
import dev.lvstrng.argon.utils.WorldUtils;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.Items;
import net.minecraft.util.hit.EntityHitResult;
import org.lwjgl.glfw.GLFW;

public final class ShieldDisabler extends Module implements TickListener, AttackListener {
	private final NumberSetting hitDelay = new NumberSetting(EncryptedString.of("Hit Delay"), 0, 20, 0, 1);
	private final NumberSetting switchDelay = new NumberSetting(EncryptedString.of("Switch Delay"), 0, 20, 0, 1);
	private final BooleanSetting switchBack = new BooleanSetting(EncryptedString.of("Switch Back"), true);
	private final BooleanSetting stun = new BooleanSetting(EncryptedString.of("Stun"), false);
	private final BooleanSetting clickSimulate = new BooleanSetting(EncryptedString.of("Click Simulation"), false);
	private final BooleanSetting requireHoldAxe = new BooleanSetting(EncryptedString.of("Hold Axe"), false);

	int previousSlot, hitClock, switchClock, attackWindow, lockClock;
	boolean axeSelected;

	public ShieldDisabler() {
		super(EncryptedString.of("Shield Disabler"),
				EncryptedString.of("Automatically disables your opponents shield"),
				-1,
				Category.COMBAT);

		addSettings(switchDelay, hitDelay, switchBack, stun, clickSimulate, requireHoldAxe);
	}

	@Override
	public void onEnable() {
		eventManager.add(TickListener.class, this);
		eventManager.add(AttackListener.class, this);

		hitClock = hitDelay.getValueInt();
		switchClock = switchDelay.getValueInt();
		previousSlot = -1;
		attackWindow = 0;
		lockClock = 0;
		axeSelected = false;
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(TickListener.class, this);
		eventManager.remove(AttackListener.class, this);

		if (mc.player != null)
			switchBackIfNeeded();

		super.onDisable();
	}

	@Override
	public void onTick() {
		if (mc.player == null)
			return;

		PlayerEntity target = getBlockingTarget();

		if (attackWindow > 0)
			attackWindow--;

		if (lockClock > 0)
			lockClock--;

		// Target nahi (click nahi / shield down / crosshair hata) -> sab reset + purane slot par wapas
		if (target == null) {
			switchBackIfNeeded();
			return;
		}

		// Abhi hit kiya hai, server se shield tootne ka wait (warna har tick dobara hit hota)
		if (lockClock > 0)
			return;

		// Step 1: Switch Delay ke baad axe par jao (sirf ek baar per fight)
		if (!axeSelected) {
			if (previousSlot == -1)
				previousSlot = mc.player.getInventory().getSelectedSlot();

			if (switchClock > 0) {
				switchClock--;
				return;
			}

			if (!InventoryUtils.selectAxe())
				return;

			axeSelected = true;
			hitClock = hitDelay.getValueInt();
		} else {
			// User ne beech mein slot badal diya ho to axe wapas select karo
			InventoryUtils.selectAxe();
		}

		// Step 2: Hit Delay (axe select hone ke baad itne tick ruko)
		if (hitClock > 0) {
			hitClock--;
			return;
		}

		// Step 3: Hit. Stun on ho to hi doosra hit, off ho to sirf ek
		int hits = stun.getValue() ? 2 : 1;

		for (int i = 0; i < hits; i++) {
			if (clickSimulate.getValue())
				MouseSimulation.mouseClick(GLFW.GLFW_MOUSE_BUTTON_LEFT);

			WorldUtils.hitEntity(target, true);
		}

		// Server se shield band hone ki khabar aane tak (ping) dobara hit nahi
		lockClock = 5;
	}

	/**
	 * Target return karta hai agar user ne khud left click dabaya hai aur crosshair
	 * ek aise player par hai jo shield se block kar raha hai. Warna null.
	 */
	private PlayerEntity getBlockingTarget() {
		if (mc.currentScreen != null)
			return null;

		if (!isUserAttacking())
			return null;

		if (requireHoldAxe.getValue() && previousSlot == -1 && !(mc.player.getMainHandStack().getItem() instanceof AxeItem))
			return null;

		if (mc.player.isUsingItem())
			return null;

		if (!(mc.crosshairTarget instanceof EntityHitResult entityHit))
			return null;

		if (!(entityHit.getEntity() instanceof PlayerEntity player))
			return null;

		if (WorldUtils.isShieldFacingAway(player))
			return null;

		if (player.isHolding(Items.SHIELD) && player.isBlocking())
			return player;

		return null;
	}

	/**
	 * User khud attack kar raha hai ya nahi: attack key hold, mouse left press,
	 * ya abhi-abhi game ne user ka click (doAttack) process kiya.
	 * Isse mouse, touch/controller sab input methods par kaam karega.
	 */
	private boolean isUserAttacking() {
		return attackWindow > 0
				|| mc.options.attackKey.isPressed()
				|| GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
	}

	private void switchBackIfNeeded() {
		if (previousSlot != -1) {
			if (switchBack.getValue())
				InventoryUtils.setInvSlot(previousSlot);

			previousSlot = -1;
		}

		axeSelected = false;
		lockClock = 0;
		hitClock = hitDelay.getValueInt();
		switchClock = switchDelay.getValueInt();
	}

	@Override
	public void onAttack(AttackListener.AttackEvent event) {
		// User ka apna click note karo (cancel nahi karna)
		// Apne simulated click ko ignore karo, warna loop ban jayega
		if (!MouseSimulation.isMouseButtonPressed(GLFW.GLFW_MOUSE_BUTTON_LEFT))
			attackWindow = 3;
	}
}
