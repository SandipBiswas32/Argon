package dev.lvstrng.argon.module.modules.combat;

import dev.lvstrng.argon.event.events.AttackListener;
import dev.lvstrng.argon.event.events.TickListener;
import dev.lvstrng.argon.module.Category;
import dev.lvstrng.argon.module.Module;
import dev.lvstrng.argon.module.setting.BooleanSetting;
import dev.lvstrng.argon.module.setting.KeybindSetting;
import dev.lvstrng.argon.module.setting.NumberSetting;
import dev.lvstrng.argon.utils.EncryptedString;
import dev.lvstrng.argon.utils.InventoryUtils;
import dev.lvstrng.argon.utils.MouseSimulation;
import dev.lvstrng.argon.utils.WorldUtils;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.Items;
import net.minecraft.util.hit.EntityHitResult;
import org.lwjgl.glfw.GLFW;

public final class ShieldDisabler extends Module implements TickListener, AttackListener {
	private final NumberSetting hitDelay = new NumberSetting(EncryptedString.of("Hit Delay"), 0, 20, 0, 1);
	private final NumberSetting switchDelay = new NumberSetting(EncryptedString.of("Switch Delay"), 0, 20, 0, 1);
	private final BooleanSetting switchBack = new BooleanSetting(EncryptedString.of("Switch Back"), true);
	private final BooleanSetting stun = new BooleanSetting(EncryptedString.of("Stun"), false);
	private final BooleanSetting clickSimulate = new BooleanSetting(EncryptedString.of("Click Simulation"), false);
	private final BooleanSetting requireHoldAxe = new BooleanSetting(EncryptedString.of("Hold Axe"), false);

	int previousSlot, hitClock, switchClock;

	public ShieldDisabler() {
		super(EncryptedString.of("Shield Disabler"),
				EncryptedString.of("Automatically disables your opponents shield"),
				-1,
				Category.COMBAT);

		addSettings(switchDelay, hitDelay, switchBack, stun, clickSimulate, requireHoldAxe);
	}

	@Override
	public void onEnable() {
		eventManager.add(TickListener.class, this);
		eventManager.add(AttackListener.class, this);

		hitClock = hitDelay.getValueInt();
		switchClock = switchDelay.getValueInt();
		previousSlot = -1;
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(TickListener.class, this);
		eventManager.remove(AttackListener.class, this);

		if (mc.player != null)
			switchBackIfNeeded();

		super.onDisable();
	}

	@Override
	public void onTick() {
		if (mc.player == null)
			return;

		PlayerEntity target = getBlockingTarget();

		// Sirf tab kaam kare jab player khud left click hold/press kar raha ho
		if (target == null) {
			switchBackIfNeeded();
			return;
		}

		if (switchClock > 0) {
			if (previousSlot == -1)
				previousSlot = mc.player.getInventory().getSelectedSlot();

			switchClock--;
			return;
		}

		if (previousSlot == -1)
			previousSlot = mc.player.getInventory().getSelectedSlot();

		if (!InventoryUtils.selectAxe())
			return;

		if (hitClock > 0) {
			hitClock--;
			return;
		}

		if (clickSimulate.getValue())
			MouseSimulation.mouseClick(GLFW.GLFW_MOUSE_BUTTON_LEFT);

		WorldUtils.hitEntity(target, true);

		if (stun.getValue()) {
			if (clickSimulate.getValue())
				MouseSimulation.mouseClick(GLFW.GLFW_MOUSE_BUTTON_LEFT);

			WorldUtils.hitEntity(target, true);
		}

		hitClock = hitDelay.getValueInt();
		switchClock = switchDelay.getValueInt();
	}

	/**
	 * Target return karta hai agar user ne khud left click dabaya hai aur crosshair
	 * ek aise player par hai jo shield se block kar raha hai. Warna null.
	 */
	private PlayerEntity getBlockingTarget() {
		if (mc.currentScreen != null)
			return null;

		if (GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), GLFW.GLFW_MOUSE_BUTTON_LEFT) != GLFW.GLFW_PRESS)
			return null;

		if (requireHoldAxe.getValue() && previousSlot == -1 && !(mc.player.getMainHandStack().getItem() instanceof AxeItem))
			return null;

		if (mc.player.isUsingItem())
			return null;

		if (!(mc.crosshairTarget instanceof EntityHitResult entityHit))
			return null;

		if (!(entityHit.getEntity() instanceof PlayerEntity player))
			return null;

		if (WorldUtils.isShieldFacingAway(player))
			return null;

		if (player.isHolding(Items.SHIELD) && player.isBlocking())
			return player;

		return null;
	}

	private void switchBackIfNeeded() {
		if (previousSlot != -1) {
			if (switchBack.getValue())
				InventoryUtils.setInvSlot(previousSlot);

			previousSlot = -1;
		}

		hitClock = hitDelay.getValueInt();
		switchClock = switchDelay.getValueInt();
	}

	@Override
	public void onAttack(AttackListener.AttackEvent event) {
		if (GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), GLFW.GLFW_MOUSE_BUTTON_LEFT) != GLFW.GLFW_PRESS)
			event.cancel();
	}
}
